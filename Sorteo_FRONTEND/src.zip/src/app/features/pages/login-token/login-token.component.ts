import { Component } from '@angular/core';

@Component({
  selector: 'app-login-token',
  standalone: true,
  imports: [],
  templateUrl: './login-token.component.html',
  styleUrl: './login-token.component.css'
})
export class LoginTokenComponent {

}
