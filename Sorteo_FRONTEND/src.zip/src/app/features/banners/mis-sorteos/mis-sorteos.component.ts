import { Component } from '@angular/core';

@Component({
  selector: 'app-mis-sorteos',
  templateUrl: './mis-sorteos.component.html',
  styleUrls: ['./mis-sorteos.component.css']
})
export class MisSorteosComponent {

}
