import { Component } from '@angular/core';

@Component({
  selector: 'app-usadas',
  templateUrl: './usadas.component.html',
  styleUrls: ['./usadas.component.css']
})
export class UsadasComponent {

}
